1. The website is built using commands in "StaticWebsite.cmd.txt" (after build and destroy using GUI)
2. "Site Build Log.txt" file contains session log of build and proof of site build
3. "Project 1 URLs.txt" file contains the three URLs which can be used to access the website